

<button type="button" name="button" class='prompt-toggle' rel='<?php echo e($rel); ?>'>Edit</button>


<div class="prompt-background" rel='<?php echo e($rel); ?>'>
  <button type="button" name="button" rel='<?php echo e($rel); ?>' class='prompt-toggle'>x</button>



<?php echo $__env->yieldPushContent($rel); ?>
</div>
