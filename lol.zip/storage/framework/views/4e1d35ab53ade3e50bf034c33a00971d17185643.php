
<?php if(count($errors->all())): ?>
  <div class="col-sm-8 col-xs-10 mx-auto " style="float: none; margin: 30px auto;">
    <ul class="list-group ">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class='list-group-item list-group-item-danger'> <?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
