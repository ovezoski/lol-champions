<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/champions/index.css')); ?>">
<div id="champions">

  <?php $__currentLoopData = $champions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $champion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <div class="champion">
    <?php if(auth()->check()): ?>
    <?php if( \Auth::user()->role ): ?>
    <form class="" action="index.html" method="post">

    </form>
    <?php endif; ?>
    <?php endif; ?>

<a href="/champions/<?php echo e($champion->name); ?>">
    <img src="/storage/<?php echo e($champion->name); ?>/profile-picture.png" alt="">
    <h1><?php echo e($champion->name); ?></h1>
  </a>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>