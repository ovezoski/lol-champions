<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/champions/abilities.css')); ?>">

<form class="" action="/champions/store" method="post">

    <div id="abilities" class="col-sm-8 col-xs-11">

      <div class="ability row">

        <h3> Passive </h3>
        <input placeholder="Title" class='title form-control' type="text" name="ability[title][]" />
        <input placeholder="Image" class='image form-control' type="text" name="ability[image][]" />
        <input placeholder="Video URL" class='video form-control' type="text" name="ability[video][]" />
        <textarea placeholder="Ability description" type="text" class='description form-control' name="ability[description][]" />
        </textarea>

      </div>
      <div class="ability row">

        <h3> Q </h3>

        <input placeholder="Title" class='title form-control' type="text" name="ability[title][]" />
        <input placeholder="Image" class='image form-control' type="text" name="ability[image][]" />
        <input placeholder="Video URL" class='video form-control' type="text" name="ability[video][]" />
        <textarea placeholder="Ability description" type="text" class='description form-control' name="ability[description][]" />
        </textarea>

      </div>
      <div class="ability row">

              <h3> W </h3>

              <input placeholder="Title" class='title form-control' type="text" name="ability[title][]" />
              <input placeholder="Image" class='image form-control' type="text" name="ability[image][]" />
              <input placeholder="Video URL" class='video form-control' type="text" name="ability[video][]" />
              <textarea placeholder="Ability description" type="text" class='description form-control' name="ability[description][]" />
              </textarea>

            </div>

            <div class="ability row">

              <h3> E </h3>

              <input placeholder="Title" class='title form-control' type="text" name="ability[title][]" />
              <input placeholder="Image" class='image form-control' type="text" name="ability[image][]" />
              <input placeholder="Video URL" class='video form-control' type="text" name="ability[video][]" />
              <textarea placeholder="Ability description" type="text" class='description form-control' name="ability[description][]" />
              </textarea>

            </div>
            <div class="ability row">

              <h3> R </h3>

              <input placeholder="Title" class='title form-control' type="text" name="ability[title][]" />
              <input placeholder="Image" class='image form-control' type="text" name="ability[image][]" />
              <input placeholder="Video URL" class='video form-control' type="text" name="ability[video][]" />
              <textarea placeholder="Ability description" type="text" class='description form-control' name="ability[description][]" />
              </textarea>

            </div>

            <input type="submit">
    </div>

<?php echo e(csrf_field()); ?>


  </form>

<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>