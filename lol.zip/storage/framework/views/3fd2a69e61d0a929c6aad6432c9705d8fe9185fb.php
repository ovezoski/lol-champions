<?php $__env->startComponent('mail::message'); ?>

Greeting summoner,

A new champion has been added to the league, make sure to check <?php echo e($champion->name); ?>`s abilities and stats <a href="<?php echo e(url('champions/').'/'.$champion->name); ?>"> here. </a>
 <?php $__env->startComponent('mail::button', ['url' => url('champions').'/'.$champion->name ]); ?>
 kako ne
 <?php echo $__env->renderComponent(); ?>

 Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
