

<img src="/storage/<?php echo e($champion->name); ?>/profile-picture.png" alt="">

<?php echo e($champion->name); ?>


-<?php echo e($champion->title); ?>


  <?php $__currentLoopData = $champion->abilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form  action="index.html" method="post">
      <?php echo e($ability::idToAbility($ability->ability)); ?>

      <input type="text" name="ability" value="<?php echo e($ability->title); ?>">
      <input type="text" name="video" value="<?php echo e($ability->video); ?>">
      <input type="submit" value = save>
    </form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
