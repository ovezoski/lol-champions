

<img src="/storage/{{$champion->name}}/profile-picture.png" alt="">

{{ $champion->name }}

-{{ $champion->title }}

  @foreach($champion->abilities as $ability)
    <form  action="index.html" method="post">
      {{ $ability::idToAbility($ability->ability) }}
      <input type="text" name="ability" value="{{ $ability->title }}">
      <input type="text" name="video" value="{{ $ability->video }}">
      <input type="submit" value = save>
    </form>
  @endforeach
