@extends('layouts.app')

@section('content')

<div class="bg-danger ">

</div>

@include('layouts.subscribe')

@endsection
