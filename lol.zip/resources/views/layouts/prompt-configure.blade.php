<style media="screen">
  .prompt-background{
    width:100%;
    height:100%;
    position: fixed;
    top:0;
    left: 0;
    background: rgba(0, 0, 0, 0.5);
    background: repeating-linear-gradient(45deg,
       rgba(0, 0, 1, 0.4) ,
       rgba(0, 0, 1, 0.4) 5px,
       rgba(0, 4, 0, 0.6) 5px,
       rgba(0, 4, 0, 0.6) 10px );
    z-index: 100000;
    display: none;
  }

  .prompt-background .prompt-toggle{
    background: red;
    border: none !important;
    color: white;
    position: fixed;
    top:  20px;
    left: 50%;
    width: 6%;
    margin-left: -3%;
    font-size: 2em;
    font-weight: 700;
  }
</style>

<script type="text/javascript">

  $('.prompt-toggle').click(function () {
    rel = $(this).attr('rel');
      $('.prompt-background[rel='+rel+']').toggle();
  });

</script>
