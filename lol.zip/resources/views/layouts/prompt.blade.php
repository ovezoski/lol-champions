

<button type="button" name="button" class='prompt-toggle' rel='{{$rel}}'>Edit</button>


<div class="prompt-background" rel='{{$rel}}'>
  <button type="button" name="button" rel='{{$rel}}' class='prompt-toggle'>x</button>



@stack($rel)
</div>
